package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee_Details")
public class Employee 
{

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private long EnployeeId;
	
	private String name;
	
	private String adress;
	
	private String city;
	
	private int pincode;
	
	private double mobileNumber;
	
	private String degree;
	
	private String designation;
	
	private String branch;
	
	private double basicPay;
	
	private double salary;
	
	private long accountNumber;
	
	private String email;
	
	private String password;
	
	private String conformPassword;

	public long getEnployeeId() {
		return EnployeeId;
	}

	public void setEnployeeId(long enployeeId) {
		EnployeeId = enployeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public double getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(double mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getBasicPay() {
		return basicPay;
	}

	public void setBasicPay(double basicPay) {
		this.basicPay = basicPay;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConformPassword() {
		return conformPassword;
	}

	public void setConformPassword(String conformPassword) {
		this.conformPassword = conformPassword;
	}

	public Employee(long enployeeId, String name, String adress, String city, int pincode, double mobileNumber,
			String degree, String designation, String branch, double basicPay, double salary, long accountNumber,
			String email, String password, String conformPassword) {
		super();
		EnployeeId = enployeeId;
		this.name = name;
		this.adress = adress;
		this.city = city;
		this.pincode = pincode;
		this.mobileNumber = mobileNumber;
		this.degree = degree;
		this.designation = designation;
		this.branch = branch;
		this.basicPay = basicPay;
		this.salary = salary;
		this.accountNumber = accountNumber;
		this.email = email;
		this.password = password;
		this.conformPassword = conformPassword;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
