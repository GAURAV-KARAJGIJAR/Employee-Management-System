package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.Entity.Employee;
import com.example.demo.reposetory.reposetory;


@Controller
public class controller {
	
	@Autowired
	reposetory repo;
	
	public List<Employee> getEmployeeData(){
		List<Employee> data=repo.findAll();
		return data;
	}
//Mapping for home page:
	@RequestMapping("/home")
	public String home(Model model) {
		 
		return "index";

	}
//..........................................................................

//Mapping for login page:
	@RequestMapping("/login")
	public String login() {

		return "login";

	}
//..........................................................................

//Mapping for Add-Employee:
	@GetMapping("/add-employee")
	public String add(Model model) {
		  model.addAttribute("employees",getEmployeeData());
		
		
		Employee employee=new Employee();
        model.addAttribute("employees1",employee);
    
		return "add_employee";

	}
//..........................................................................

	@RequestMapping("/update")
	public String delete() {
		
		return "update_employee";
	}
	
//..........................................................................
	
//Mapping for delete-Employee:
	@RequestMapping("/delete")
	public String update() {

		return "delete_employee";

	}

//..........................................................................
	
//Mapping for View-Employee:
	@RequestMapping("/view")
	public String view(Model model) {
		model.addAttribute("employees",getEmployeeData());
		return "viewEmployee";

	}

//..........................................................................
	
	@PostMapping("/index1")
	public String AddEmployee( @ModelAttribute("employees1") Employee employee) {
		repo.save(employee);
		return "redirect:/home";
		
	}
	

}
